/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proga2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author pheme
 */
public class OrphanedAnimalRescueTest {
    
    public OrphanedAnimalRescueTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getRescueType method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        OrphanedAnimalRescue instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateAdditionalCost method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testCalculateAdditionalCost() {
        System.out.println("calculateAdditionalCost");
        OrphanedAnimalRescue instance = null;
        double expResult = 0.0;
        double result = instance.calculateAdditionalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        OrphanedAnimalRescue instance = null;
        RescuePriority expResult = null;
        RescuePriority result = instance.determinePriority();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecificDetails method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testGetSpecificDetails() {
        System.out.println("getSpecificDetails");
        OrphanedAnimalRescue instance = null;
        String expResult = "";
        String result = instance.getSpecificDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAgeInMonths method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testGetAgeInMonths() {
        System.out.println("getAgeInMonths");
        OrphanedAnimalRescue instance = null;
        int expResult = 0;
        int result = instance.getAgeInMonths();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFeedingCost method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testGetFeedingCost() {
        System.out.println("getFeedingCost");
        OrphanedAnimalRescue instance = null;
        double expResult = 0.0;
        double result = instance.getFeedingCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isFosterCareRequired method, of class OrphanedAnimalRescue.
     */
    @Test
    public void testIsFosterCareRequired() {
        System.out.println("isFosterCareRequired");
        OrphanedAnimalRescue instance = null;
        boolean expResult = false;
        boolean result = instance.isFosterCareRequired();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
