/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proga2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author pheme
 */
public class InjuredAnimalRescueTest {
    
    public InjuredAnimalRescueTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getRescueType method, of class InjuredAnimalRescue.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        InjuredAnimalRescue instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateAdditionalCost method, of class InjuredAnimalRescue.
     */
    @Test
    public void testCalculateAdditionalCost() {
        System.out.println("calculateAdditionalCost");
        InjuredAnimalRescue instance = null;
        double expResult = 0.0;
        double result = instance.calculateAdditionalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class InjuredAnimalRescue.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        InjuredAnimalRescue instance = null;
        RescuePriority expResult = null;
        RescuePriority result = instance.determinePriority();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecificDetails method, of class InjuredAnimalRescue.
     */
    @Test
    public void testGetSpecificDetails() {
        System.out.println("getSpecificDetails");
        InjuredAnimalRescue instance = null;
        String expResult = "";
        String result = instance.getSpecificDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getInjuryDescription method, of class InjuredAnimalRescue.
     */
    @Test
    public void testGetInjuryDescription() {
        System.out.println("getInjuryDescription");
        InjuredAnimalRescue instance = null;
        String expResult = "";
        String result = instance.getInjuryDescription();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getVeterinaryCost method, of class InjuredAnimalRescue.
     */
    @Test
    public void testGetVeterinaryCost() {
        System.out.println("getVeterinaryCost");
        InjuredAnimalRescue instance = null;
        double expResult = 0.0;
        double result = instance.getVeterinaryCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isSurgeryRequired method, of class InjuredAnimalRescue.
     */
    @Test
    public void testIsSurgeryRequired() {
        System.out.println("isSurgeryRequired");
        InjuredAnimalRescue instance = null;
        boolean expResult = false;
        boolean result = instance.isSurgeryRequired();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
